
True Type Font: Pixel LCD-7 version 1.0


EULA
-==-
The fonts Pixel LCD-7 is freeware for home using.


DESCRIPTION
-=========-

Original pixel font like seven-segment clock faces. Native size is 15 points. Only Cyrillic code page is supported.

Files in pixel_lcd-7.zip:
       	readme.txt     		this file;
        pixel_lcd-7.ttf    	Pixel LCD-7 regular font;
	pixel_lcd-7.fon   	Pixel LCD-7 regular font in Windows OS "FON" format;
	pixel_lcd-7_screen.png	preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-=================-

Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-

Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-

Sizenko Alexander
Style-7
http://www.styleseven.com
Created: November 24 2012